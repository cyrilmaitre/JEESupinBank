package com.supinfo.supinfbank.util;

public class Constants 
{
	public static final String ACCOUNTYPE[] = 	
	{
		"Current Account",
		"Savings Account",
		"Life Insurance",
		"First Home Saver Account"
	};	
}
