package com.supinfo.supinfbank.dao;

import javax.ejb.Local;

import com.supinfo.supinfbank.entity.AccountType;


@Local
public interface AccountTypeDao extends Dao<AccountType> 
{

}
