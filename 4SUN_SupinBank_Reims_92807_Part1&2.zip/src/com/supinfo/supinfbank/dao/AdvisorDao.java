package com.supinfo.supinfbank.dao;

import javax.ejb.Local;

import com.supinfo.supinfbank.entity.Advisor;


@Local
public interface AdvisorDao extends Dao<Advisor>
{

}
