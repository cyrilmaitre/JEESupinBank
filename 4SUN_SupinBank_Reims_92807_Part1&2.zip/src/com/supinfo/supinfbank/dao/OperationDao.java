package com.supinfo.supinfbank.dao;

import javax.ejb.Local;

import com.supinfo.supinfbank.entity.Operation;


@Local
public interface OperationDao extends Dao<Operation>
{

}
