package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.Customer;

@Stateless
public class CustomerValidator extends AbstractValidator<Customer>
{

}
