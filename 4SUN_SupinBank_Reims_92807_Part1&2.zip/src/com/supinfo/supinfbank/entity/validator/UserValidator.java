package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.User;

@Stateless
public class UserValidator extends AbstractValidator<User>
{

}
