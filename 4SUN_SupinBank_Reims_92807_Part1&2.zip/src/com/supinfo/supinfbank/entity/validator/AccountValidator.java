package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.Account;


@Stateless
public class AccountValidator extends AbstractValidator<Account>
{

}
