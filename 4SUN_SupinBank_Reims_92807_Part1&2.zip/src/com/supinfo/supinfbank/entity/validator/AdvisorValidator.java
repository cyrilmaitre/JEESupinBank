package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.Advisor;

@Stateless
public class AdvisorValidator extends AbstractValidator<Advisor>
{

}
