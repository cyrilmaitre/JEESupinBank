package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.Operation;

@Stateless
public class OperationValidator extends AbstractValidator<Operation>
{

}
