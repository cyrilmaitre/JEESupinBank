package com.supinfo.supinfbank.entity.validator;

import javax.ejb.Stateless;

import com.supinfo.supinfbank.entity.AccountType;

@Stateless
public class AccountTypeValidator extends AbstractValidator<AccountType> 
{

}
